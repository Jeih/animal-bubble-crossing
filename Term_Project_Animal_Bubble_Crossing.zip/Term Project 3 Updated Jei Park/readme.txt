
Name : Jei Park
Project Name : "Animal Crossing Fruits and Bubble World"

Info: Players kill their opponents by setting balloons that pop and release both vertically and horizontally. The player can kill the minions with bubbles. The player can collect fruits and enjoy the nature.

How to play:
For Mac, press command + B to run. Use keys to move the player, use space bar to set the balloons.

!! The minion that moves left to right does not disappear by the balloons. It is just there to look cute!!
No extra installation required

No shortcut commands.
